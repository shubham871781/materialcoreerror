import React from 'react'

function TakeAppoinments() {
  return (
    <div>TakeAppoinments</div>
  )
}

export default TakeAppoinments