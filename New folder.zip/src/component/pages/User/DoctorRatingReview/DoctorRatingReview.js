import React from 'react'

function DoctorRatingReview() {
  return (
    <div>DoctorRatingReview</div>
  )
}

export default DoctorRatingReview