import React from 'react'

function DoctorTiming() {
  return (
    <div>DoctorTiming</div>
  )
}

export default DoctorTiming