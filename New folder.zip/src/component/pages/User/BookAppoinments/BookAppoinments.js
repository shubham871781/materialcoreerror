import React from 'react'

function BookAppoinments() {
  return (
    <>
        
    </>  
  )
}

export default BookAppoinments