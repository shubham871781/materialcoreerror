import React from 'react';
import {API_URL, VIEWDOCTORLOCATION} from '../../../../Apiconst/Apiconst';
function ViewDoctorLocation() {
    
  return (
    <>
        
    </>
  )
}

export default ViewDoctorLocation