import React from 'react'

function RegistrationFormModal() {
  return (
    <>
       
    </>
  )
}

export default RegistrationFormModal