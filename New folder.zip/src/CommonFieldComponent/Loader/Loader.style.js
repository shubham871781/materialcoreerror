import style, { css } from "styled-components";

function loaderStyle() {
  return css`
    
  `;
}

export const LoaderWrapperStyled = style.div`
    ${loaderStyle};
`;
